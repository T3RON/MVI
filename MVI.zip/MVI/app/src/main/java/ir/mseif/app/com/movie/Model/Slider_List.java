package ir.mseif.app.com.movie.Model;

public class Slider_List {
    public int sliders_id;
    public int movie_id;
    public int series_id;
    public String sliders_title;
    public String image_url;
    public String sliders_type;


    public int getSliders_id() {
        return sliders_id;
    }

    public void setSliders_id(int sliders_id) {
        this.sliders_id = sliders_id;
    }

    public int getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public int getSeries_id() {
        return series_id;
    }

    public void setSeries_id(int series_id) {
        this.series_id = series_id;
    }

    public String getSliders_title() {
        return sliders_title;
    }

    public void setSliders_title(String sliders_title) {
        this.sliders_title = sliders_title;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getSliders_type() {
        return sliders_type;
    }

    public void setSliders_type(String sliders_type) {
        this.sliders_type = sliders_type;
    }
}
