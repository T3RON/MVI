package ir.mseif.app.com.movie.NetworkClass;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;

public class NetworkGet {


}
