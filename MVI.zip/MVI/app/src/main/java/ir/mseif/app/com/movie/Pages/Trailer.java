package ir.mseif.app.com.movie.Pages;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ir.mseif.app.com.movie.R;

public class Trailer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trailer);
    }
}
